package com.example.skeri;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BottomNavigation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_navigation);
    }
}